<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main_page extends CI_Controller {


	public function index()
	{
	    $data['student'] = $this->m_record->get_data('student')->result();
			$data['attendance'] = $this->m_record->get_data('attendance')->result();
			$data['ageing'] = $this->m_record->get_data_ageing()->result();
		$this->load->view('appmodule/dashboard',$data);

	}
}
